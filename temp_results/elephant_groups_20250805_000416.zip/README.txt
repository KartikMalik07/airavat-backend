
Elephant Grouping Results - 20250805_000416

Total Images Processed: 29
Groups Created: 13
Model Used: yolo

This is a demo result. In full mode, actual elephant images would be grouped by similarity.

For each group, you would find:
- Original images grouped by similarity
- Confidence scores for each match
- Detailed analysis reports
