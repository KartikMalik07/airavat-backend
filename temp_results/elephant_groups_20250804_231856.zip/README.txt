
Elephant Grouping Results - 20250804_231856

Total Images Processed: 29
Groups Created: 11
Model Used: siamese

This is a demo result. In full mode, actual elephant images would be grouped by similarity.

For each group, you would find:
- Original images grouped by similarity
- Confidence scores for each match
- Detailed analysis reports
